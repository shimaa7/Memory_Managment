﻿namespace Memory_Managment
{
    partial class memoryManagment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(memoryManagment));
            this.radioButtonFirstFit = new System.Windows.Forms.RadioButton();
            this.radioButtonBestFit = new System.Windows.Forms.RadioButton();
            this.radioButtonWorstFit = new System.Windows.Forms.RadioButton();
            this.radioButtonComputex = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.domainUpDownProcessName = new System.Windows.Forms.DomainUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelNumber = new System.Windows.Forms.Label();
            this.buttonADD = new System.Windows.Forms.Button();
            this.domainUpDownProcessSize = new System.Windows.Forms.DomainUpDown();
            this.REMOVE = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxStartingAddress = new System.Windows.Forms.TextBox();
            this.textBoxMemorySize = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.domainUpDownHoleStarting = new System.Windows.Forms.DomainUpDown();
            this.domainUpDownHoleSize = new System.Windows.Forms.DomainUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.labelNumberOfHoles = new System.Windows.Forms.Label();
            this.Form2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // radioButtonFirstFit
            // 
            this.radioButtonFirstFit.AutoSize = true;
            this.radioButtonFirstFit.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonFirstFit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonFirstFit.ForeColor = System.Drawing.Color.Thistle;
            this.radioButtonFirstFit.Location = new System.Drawing.Point(78, 135);
            this.radioButtonFirstFit.Name = "radioButtonFirstFit";
            this.radioButtonFirstFit.Size = new System.Drawing.Size(88, 24);
            this.radioButtonFirstFit.TabIndex = 0;
            this.radioButtonFirstFit.TabStop = true;
            this.radioButtonFirstFit.Text = "First Fit";
            this.radioButtonFirstFit.UseVisualStyleBackColor = false;
            // 
            // radioButtonBestFit
            // 
            this.radioButtonBestFit.AutoSize = true;
            this.radioButtonBestFit.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonBestFit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonBestFit.ForeColor = System.Drawing.Color.Thistle;
            this.radioButtonBestFit.Location = new System.Drawing.Point(258, 135);
            this.radioButtonBestFit.Name = "radioButtonBestFit";
            this.radioButtonBestFit.Size = new System.Drawing.Size(89, 24);
            this.radioButtonBestFit.TabIndex = 1;
            this.radioButtonBestFit.TabStop = true;
            this.radioButtonBestFit.Text = "Best Fit";
            this.radioButtonBestFit.UseVisualStyleBackColor = false;
            // 
            // radioButtonWorstFit
            // 
            this.radioButtonWorstFit.AutoSize = true;
            this.radioButtonWorstFit.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonWorstFit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonWorstFit.ForeColor = System.Drawing.Color.Thistle;
            this.radioButtonWorstFit.Location = new System.Drawing.Point(432, 135);
            this.radioButtonWorstFit.Name = "radioButtonWorstFit";
            this.radioButtonWorstFit.Size = new System.Drawing.Size(99, 24);
            this.radioButtonWorstFit.TabIndex = 2;
            this.radioButtonWorstFit.TabStop = true;
            this.radioButtonWorstFit.Text = "Worst Fit";
            this.radioButtonWorstFit.UseVisualStyleBackColor = false;
            // 
            // radioButtonComputex
            // 
            this.radioButtonComputex.AutoSize = true;
            this.radioButtonComputex.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonComputex.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonComputex.ForeColor = System.Drawing.Color.Thistle;
            this.radioButtonComputex.Location = new System.Drawing.Point(596, 135);
            this.radioButtonComputex.Name = "radioButtonComputex";
            this.radioButtonComputex.Size = new System.Drawing.Size(105, 24);
            this.radioButtonComputex.TabIndex = 3;
            this.radioButtonComputex.TabStop = true;
            this.radioButtonComputex.Text = "Computex";
            this.radioButtonComputex.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Violet;
            this.label1.Location = new System.Drawing.Point(190, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(362, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Memory Managment System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Thistle;
            this.label2.Location = new System.Drawing.Point(62, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(213, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Select Type of Managment:";
            // 
            // domainUpDownProcessName
            // 
            this.domainUpDownProcessName.Location = new System.Drawing.Point(60, 213);
            this.domainUpDownProcessName.Name = "domainUpDownProcessName";
            this.domainUpDownProcessName.Size = new System.Drawing.Size(120, 22);
            this.domainUpDownProcessName.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Thistle;
            this.label4.Location = new System.Drawing.Point(250, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Process Size";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Thistle;
            this.label5.Location = new System.Drawing.Point(57, 188);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Process Name";
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.BackColor = System.Drawing.Color.Violet;
            this.labelNumber.Location = new System.Drawing.Point(408, 216);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(16, 17);
            this.labelNumber.TabIndex = 12;
            this.labelNumber.Text = "0";
            // 
            // buttonADD
            // 
            this.buttonADD.Location = new System.Drawing.Point(450, 213);
            this.buttonADD.Name = "buttonADD";
            this.buttonADD.Size = new System.Drawing.Size(121, 23);
            this.buttonADD.TabIndex = 14;
            this.buttonADD.Text = "ADD Process";
            this.buttonADD.UseVisualStyleBackColor = true;
            this.buttonADD.Click += new System.EventHandler(this.buttonADD_Click);
            // 
            // domainUpDownProcessSize
            // 
            this.domainUpDownProcessSize.Location = new System.Drawing.Point(254, 213);
            this.domainUpDownProcessSize.Name = "domainUpDownProcessSize";
            this.domainUpDownProcessSize.Size = new System.Drawing.Size(120, 22);
            this.domainUpDownProcessSize.TabIndex = 9;
            // 
            // REMOVE
            // 
            this.REMOVE.Location = new System.Drawing.Point(484, 369);
            this.REMOVE.Name = "REMOVE";
            this.REMOVE.Size = new System.Drawing.Size(226, 23);
            this.REMOVE.TabIndex = 17;
            this.REMOVE.Text = "REMOVE ALL";
            this.REMOVE.UseVisualStyleBackColor = true;
            this.REMOVE.Click += new System.EventHandler(this.REMOVE_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Thistle;
            this.label6.Location = new System.Drawing.Point(57, 315);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(222, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "Starting Address Of Memory";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Thistle;
            this.label7.Location = new System.Drawing.Point(57, 366);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 20);
            this.label7.TabIndex = 19;
            this.label7.Text = "Memory Size";
            // 
            // textBoxStartingAddress
            // 
            this.textBoxStartingAddress.Location = new System.Drawing.Point(59, 336);
            this.textBoxStartingAddress.Name = "textBoxStartingAddress";
            this.textBoxStartingAddress.Size = new System.Drawing.Size(141, 22);
            this.textBoxStartingAddress.TabIndex = 20;
            // 
            // textBoxMemorySize
            // 
            this.textBoxMemorySize.Location = new System.Drawing.Point(59, 387);
            this.textBoxMemorySize.Name = "textBoxMemorySize";
            this.textBoxMemorySize.Size = new System.Drawing.Size(141, 22);
            this.textBoxMemorySize.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Thistle;
            this.label8.Location = new System.Drawing.Point(56, 238);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 20);
            this.label8.TabIndex = 22;
            this.label8.Text = "Hole Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Thistle;
            this.label9.Location = new System.Drawing.Point(251, 240);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "Hole Size";
            // 
            // domainUpDownHoleStarting
            // 
            this.domainUpDownHoleStarting.Location = new System.Drawing.Point(59, 259);
            this.domainUpDownHoleStarting.Name = "domainUpDownHoleStarting";
            this.domainUpDownHoleStarting.Size = new System.Drawing.Size(120, 22);
            this.domainUpDownHoleStarting.TabIndex = 24;
            // 
            // domainUpDownHoleSize
            // 
            this.domainUpDownHoleSize.Location = new System.Drawing.Point(254, 259);
            this.domainUpDownHoleSize.Name = "domainUpDownHoleSize";
            this.domainUpDownHoleSize.Size = new System.Drawing.Size(120, 22);
            this.domainUpDownHoleSize.TabIndex = 25;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(450, 260);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 23);
            this.button1.TabIndex = 26;
            this.button1.Text = "ADD Hole";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelNumberOfHoles
            // 
            this.labelNumberOfHoles.AutoSize = true;
            this.labelNumberOfHoles.BackColor = System.Drawing.Color.Violet;
            this.labelNumberOfHoles.Location = new System.Drawing.Point(408, 264);
            this.labelNumberOfHoles.Name = "labelNumberOfHoles";
            this.labelNumberOfHoles.Size = new System.Drawing.Size(16, 17);
            this.labelNumberOfHoles.TabIndex = 27;
            this.labelNumberOfHoles.Text = "0";
            // 
            // Form2
            // 
            this.Form2.Location = new System.Drawing.Point(484, 398);
            this.Form2.Name = "Form2";
            this.Form2.Size = new System.Drawing.Size(226, 26);
            this.Form2.TabIndex = 29;
            this.Form2.Text = "ALLOCATE";
            this.Form2.UseVisualStyleBackColor = true;
            this.Form2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(59, 426);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(141, 29);
            this.button3.TabIndex = 30;
            this.button3.Text = "Add Memory";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(578, 213);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(132, 23);
            this.button4.TabIndex = 31;
            this.button4.Text = "Clear Processes";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(578, 260);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(132, 23);
            this.button5.TabIndex = 32;
            this.button5.Text = "Clear Holes";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(484, 430);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(226, 26);
            this.button2.TabIndex = 33;
            this.button2.Text = "REFRISHING";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // memoryManagment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(736, 480);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.Form2);
            this.Controls.Add(this.labelNumberOfHoles);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.domainUpDownHoleSize);
            this.Controls.Add(this.domainUpDownHoleStarting);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxMemorySize);
            this.Controls.Add(this.textBoxStartingAddress);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.REMOVE);
            this.Controls.Add(this.buttonADD);
            this.Controls.Add(this.labelNumber);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.domainUpDownProcessSize);
            this.Controls.Add(this.domainUpDownProcessName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButtonComputex);
            this.Controls.Add(this.radioButtonWorstFit);
            this.Controls.Add(this.radioButtonBestFit);
            this.Controls.Add(this.radioButtonFirstFit);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "memoryManagment";
            this.Text = "Memory Managment";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButtonFirstFit;
        private System.Windows.Forms.RadioButton radioButtonBestFit;
        private System.Windows.Forms.RadioButton radioButtonWorstFit;
        private System.Windows.Forms.RadioButton radioButtonComputex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DomainUpDown domainUpDownProcessName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.Button buttonADD;
        private System.Windows.Forms.DomainUpDown domainUpDownProcessSize;
        private System.Windows.Forms.Button REMOVE;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxStartingAddress;
        private System.Windows.Forms.TextBox textBoxMemorySize;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DomainUpDown domainUpDownHoleStarting;
        private System.Windows.Forms.DomainUpDown domainUpDownHoleSize;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labelNumberOfHoles;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button Form2;
        private System.Windows.Forms.Button button2;
    }
}

